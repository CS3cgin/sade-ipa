#!/bin/bash
set -euo pipefail

task_root="$(cd "$(dirname "$0")/.." && pwd)"
if [[ "$(uname -s)" != "Darwin" ]]; then
    echo "Bu betik macOS ve Xcode gerektirir." >&2
    exit 1
fi
for task_command in xcodebuild swift make ldid zip unzip python3; do
    command -v "$task_command" >/dev/null || { echo "Eksik araç: $task_command" >&2; exit 1; }
done

cd "$task_root"
swift test
cd "$task_root/SideStore"
git submodule update --init --recursive
xcodebuild -resolvePackageDependencies -project AltStore.xcodeproj -scheme SideStore
make build fakesign ipa
mkdir -p "$task_root/build"
cp SideStore.ipa "$task_root/build/SadeIPA.ipa"
python3 "$task_root/scripts/verify-ipa.py"
echo "Hazır: $task_root/build/SadeIPA.ipa (telefona kurulmadan önce iloader ile imzalanmalı)"
