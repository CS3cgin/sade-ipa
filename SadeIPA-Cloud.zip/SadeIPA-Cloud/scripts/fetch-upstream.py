"""Restore the exact upstream sources and apply the exported Sade IPA changes."""
from pathlib import Path
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
manifest = json.loads((ROOT / "upstream.json").read_text(encoding="utf-8"))
destination = ROOT / "SideStore"
if destination.exists():
    raise SystemExit("SideStore zaten mevcut. Bu betik temiz bulut derleme paketinde çalıştırılır.")

def run(*arguments, cwd=ROOT):
    subprocess.run(arguments, cwd=cwd, check=True)

run("git", "init", str(destination))
run("git", "remote", "add", "origin", manifest["url"], cwd=destination)
run("git", "fetch", "--depth", "1", "origin", "tag", manifest["tag"], cwd=destination)
run("git", "checkout", "--detach", manifest["commit"], cwd=destination)
actual = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=destination, text=True).strip()
if actual != manifest["commit"]:
    raise SystemExit("Upstream commit beklenen sürümle eşleşmiyor.")
run("git", "submodule", "update", "--init", "--recursive", "--depth", "1", cwd=destination)
for relative, expected in manifest["submodules"].items():
    actual = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=destination / relative, text=True).strip()
    if actual != expected:
        raise SystemExit(f"Alt modül sürümü eşleşmiyor: {relative}")
patch = str(ROOT / "upstream.patch")
run("git", "apply", "--check", patch, cwd=destination)
run("git", "apply", patch, cwd=destination)
overlay = ROOT / "overlay"
for source in sorted(overlay.rglob("*")):
    if source.is_file():
        target = destination / source.relative_to(overlay)
        if target.exists():
            raise SystemExit(f"Yeni kaynak dosyası upstream ile çakışıyor: {target}")
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
print("Sabitlenmiş kaynaklar ve Sade IPA arayüzü hazır.")
