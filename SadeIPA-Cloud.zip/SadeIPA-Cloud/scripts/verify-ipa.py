"""Check the archive before presenting it as an installable build artifact."""
from pathlib import Path
import hashlib
import plistlib
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
ipa = ROOT / "build/SadeIPA.ipa"
app = "Payload/SideStore.app/"
with zipfile.ZipFile(ipa) as package:
    damaged = package.testzip()
    if damaged:
        raise SystemExit(f"IPA bozuk ZIP girdisi içeriyor: {damaged}")
    info = plistlib.loads(package.read(app + "Info.plist"))
    if info.get("CFBundleDisplayName") != "Sade IPA":
        raise SystemExit("IPA özel Sade IPA arayüzüyle paketlenmemiş.")
    if info.get("CFBundleIdentifier") != "com.SideStore.SideStore":
        raise SystemExit("Yükleyicinin bundle kimliği beklenen değerle eşleşmiyor.")
    for executable in [app + info["CFBundleExecutable"], app + "PlugIns/AltWidgetExtension.appex/AltWidgetExtension", app + "SideBackup.ipa"]:
        if executable not in package.namelist() or package.getinfo(executable).file_size == 0:
            raise SystemExit(f"IPA bileşeni eksik: {executable}")
digest = hashlib.sha256(ipa.read_bytes()).hexdigest()
(ipa.parent / "SHA256SUMS.txt").write_text(f"{digest}  SadeIPA.ipa\n", encoding="utf-8")
commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT / "SideStore", text=True).strip()
xcode = subprocess.check_output(["xcodebuild", "-version"], text=True).strip()
(ipa.parent / "BUILD-INFO.txt").write_text(
    f"Sade IPA\nUpstream: {commit}\n{xcode}\n"
    "Paket iloader ile kendi Apple hesabın kullanılarak imzalanmalı.\n"
    "iPhone 16 / iOS 27.0.1 cihaz testi henüz yapılmadı.\n", encoding="utf-8")
print(f"IPA paket kontrolü geçti: {ipa.name} ({ipa.stat().st_size:,} bytes)")
