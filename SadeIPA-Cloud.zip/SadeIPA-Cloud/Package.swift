// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "SadeIPACore",
    products: [.library(name: "SadeIPACore", targets: ["SadeIPACore"])],
    targets: [
        .target(name: "SadeIPACore", path: "SideStore/AltStore/My Apps/SadeUI",
                exclude: ["SadeAppsView.swift", "SadeSettingsView.swift", "SadeReminders.swift"],
                sources: ["SadeLifetime.swift"]),
        .testTarget(name: "SadeIPACoreTests", dependencies: ["SadeIPACore"], path: "Tests")
    ]
)
