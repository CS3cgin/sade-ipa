// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "SadeIPACore",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [.library(name: "SadeIPACore", targets: ["SadeIPACore"])],
    targets: [
        .target(name: "SadeIPACore", path: "SideStore/AltStore/My Apps/SadeUI",
                exclude: ["SadeAppsView.swift", "SadeSettingsView.swift", "SadeReminders.swift", "SadeAccountStatus.swift"],
                sources: ["SadeLifetime.swift", "SadeProgressObservation.swift"]),
        .testTarget(name: "SadeIPACoreTests", dependencies: ["SadeIPACore"], path: "Tests")
    ]
)
