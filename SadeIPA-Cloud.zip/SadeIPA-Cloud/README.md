# Sade IPA · Windows ile ilk kurulum

Mac'in olmasa da GitHub Actions'ın macOS makinesinde IPA üretebilirsin. Ardından Windows'tan USB ile iPhone'una kurarsın.

**Mevcut durum:** [public GitHub deposu](https://github.com/CS3cgin/sade-ipa) ve macOS derleme akışı kuruldu. Son derlemenin sonucunu Actions bölümünden kontrol et. Kullanıcının iPhone 16 / iOS 27.0.1 cihazında kurulum ve eşleştirme tamamlandı. Art arda yenilemede profiller başarıyla kurulmasına rağmen arayüzün beklediği gözlendi. Arayüz güncellemelerini ana iş parçacığına aktaran düzeltmenin cihaz testi gereklidir. USB olmadan yenileme, başka IPA yükleme ve ücretli hesap testleri ayrıca gereklidir.

## 1. GitHub deposu

Depo [CS3cgin/sade-ipa](https://github.com/CS3cgin/sade-ipa) adresinde hazır. Kökünde `SadeIPA-Cloud.zip`, `README.md`, `LICENSE` ve `.github/workflows/build-ipa.yml` bulunur. Akış ZIP'in SHA-256 değerini doğrular, kaynakları açar, sabitlenmiş SideStore ve alt modüllerini indirip arayüz değişikliklerini uygular.

Kaynakları incelemek için ZIP'i ayıkla. İçindeki `upstream.json` sürümleri, `upstream.patch` değişiklikleri, `overlay/` yeni Swift dosyalarını içerir. Yeniden oluşturmak için temiz bir klasörde `python3 scripts/fetch-upstream.py` çalıştır. Hesap, parola, sertifika ve cihaz eşleştirme dosyası paket içinde bulunmaz; derleme için bunlar istenmez.

Kod değişince `scripts/prepare-cloud-build.py` yeni ZIP ve ona ait workflow hash'ini üretir. ZIP ile `build/github-upload/build-ipa.yml` dosyasını birlikte güncelle; farklı paket ve hash derlemeyi durdurur.

## 2. IPA üret

1. Depoda **Actions** sekmesine gir.
2. **Sade IPA derle** akışını seç → **Run workflow** → `main` → **Run workflow**.
3. Çalıştırma tamamlanana kadar bekle. İlk derleme uzun sürebilir.
4. Yeşil tamamlanırsa çalıştırmanın altındaki **Artifacts → SadeIPA** paketini indir.
5. İnen ZIP'i aç. İçinden `SadeIPA.ipa` çıkar; telefona kurulacak dosya budur.

Kırmızı hata varsa çalıştırma sayfasını veya **SadeIPA-derleme-gunlugu** dosyasını incele. Başarısız derlemeyi yeniden başlatmak yerine hatayı düzeltmek gerekir. `Run workflow` görünmüyorsa akışın varsayılan dalda ve doğru yolda bulunduğunu kontrol et.

## 3. Windows'tan iPhone'a kur

1. [Resmî iloader](https://iloader.app/) sitesinden Windows sürümünü indir ve kur. Apple USB sürücüleri için iTunes gereklidir; [SideStore gereksinimleri](https://docs.sidestore.io/docs/installation/prerequisites) bağlantısındaki Windows bölümünü izle.
2. iPhone'u USB ile bağla, kilidini aç ve **Bu bilgisayara güven** isteğini onayla.
3. iloader'ı aç, Apple hesabınla giriş yap ve kendi IPA dosyanı yükleme akışında **SadeIPA.ipa** seç.
4. **Install SideStore (Stable)** düğmesi resmî uygulamayı indirir. Sade IPA için derlediğin dosyayı seçmelisin.
5. iPhone'da **Ayarlar → Genel → VPN ve Aygıt Yönetimi** üzerinden geliştirici hesabına güven. **Ayarlar → Gizlilik ve Güvenlik → Geliştirici Modu** istenirse etkinleştir ve telefonu yeniden başlat.
6. Telefona App Store'dan **LocalDevVPN** kur. Wi-Fi'ye bağlan ve LocalDevVPN'i aç.
7. Eşleştirme için iloader'ın **Manage Pairing File → Export** seçeneğinden dosyayı `ALTPairingFile.mobiledevicepairing` adıyla kaydet. iTunes **Dosya Paylaşımı → Sade IPA → Dosya Ekle** ile USB üzerinden aktar. Uygulama adı değiştiğinden iloader'ın otomatik SideStore listesinde görünmeyebilir. Ayrıntılı adımlar [iPhone kurulum rehberinde](docs/IPHONE-KURULUM.md).
8. Sade IPA'da **Ayarlar → Hesap ve kurulum** aç. Aynı Apple hesabıyla giriş yap.
9. Telefon hâlâ bilgisayara bağlıyken **Tümünü yenile → Yenile → Tümünü yenile** sırasıyla dene. Her işlem uygulama açıkken tamamlanmalı ve düğmeler yeniden kullanılabilmelidir. Başarıyı ve gerçek profil bitiş tarihini kontrol et. Ardından bilgisayar bağlantısını çıkarıp aynı denemeyi telefondan tekrarla.

## Kullanım sınırları

Ücretsiz Apple hesabında imza 7 gün sürer; süre bitmeden yenile. iOS arka plan çalışma zamanını belirlediği için tam 7. günde otomatik yenileme garanti değildir. Süre takibi ve son gün hatırlatması bu nedenle bulunur. Ücretsiz hesapta yükleyici dahil 3 aktif uygulama sınırı vardır.

Ücretli Apple Developer hesabı da aynı IPA ile kullanılır: 365 güne kadar profil süresi ve ücretsiz hesaptaki 3 uygulama sınırının kaldırılması desteklenir. Uygulama hesabın seçili geliştirici takımını okuyup süre/sınır bilgisini günceller. Sayaç, varsayılan bir yılı değil her uygulamanın gerçek profil tarihini gösterir. Ücretsizden ücretliye geçince **Ayarlar → Hesap ve kurulum** üzerinden yeniden giriş yapıp ücretli takımı seç ve uygulamaları yenile. Eski imza üyelik değişince kendiliğinden uzamaz. Her iki hesap türüyle telefon testi ayrıca gereklidir.

Sonraki işlemler Wi-Fi + LocalDevVPN ile telefondan hedeflenir. iOS güncellemesi, eşleştirme kaydının bozulması veya yükleyicinin imzasının tamamen dolması tekrar bilgisayar kullanımını gerektirebilir. Bu uyarlama, SideStore'un bundle kimliğini korur; mevcut SideStore'u değiştirebilir. Upstream güncellemesi özel arayüzü geri getirebilir.

## Kaynak ve lisans

Altyapı: [SideStore 0.7.0-alpha](https://github.com/SideStore/SideStore/releases/tag/0.7.0-alpha), commit `6032424a0e56c1c319762e786099bdd9186a238b`. Önceki 0.6.4 sürümü Apple tarafındaki değişiklik sonrası giriş yapamadığı için kullanılmıyor. Bu sürüm, upstream'in yayımladığı geçici giriş düzeltmesini içerir ve cihaz testi gerektirir.

Kaynağı yeniden oluşturmak için bu depoyu temiz bir klasöre indir ve `python3 scripts/fetch-upstream.py` çalıştır. `upstream.json` sürüm kimliklerini, `upstream.patch` mevcut dosya değişikliklerini, `overlay/` yeni arayüz kaynaklarını içerir. Özgün telif bildirimleri korunur; uyarlama AGPL-3.0 lisansındadır. `LICENSE` tam metindir. Bu proje resmî SideStore dağıtımı değildir.

Resmî açıklamalar: [GitHub macOS makineleri](https://docs.github.com/en/actions/reference/runners/github-hosted-runners), [GitHub Actions ücret ve kota](https://docs.github.com/en/actions/concepts/billing-and-usage), [akışı elle çalıştırma](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow), [SideStore ilk kurulum](https://docs.sidestore.io/docs/installation/install), [iloader kaynak kodu](https://github.com/nab138/iloader).
