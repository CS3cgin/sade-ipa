# Sade IPA · Windows ile ilk kurulum

Mac'in olmasa da GitHub Actions'ın macOS makinesinde IPA üretebilirsin. Ardından Windows'tan USB ile iPhone'una kurarsın.

**Mevcut durum:** kaynak ve derleme akışı hazırlandı. Bulut derlemesi henüz çalıştırılmadı; IPA henüz üretilmedi. iPhone 16 / iOS 27.0.1 üzerinde kurulum, hesap girişi ve kendini yenileme doğrulanmadı.

## 1. Derleme paketini GitHub'a yükle

1. `SadeIPA-Cloud.zip` dosyasına sağ tıkla → **Tümünü ayıkla**.
2. [GitHub'da yeni depo oluştur](https://github.com/new). Adı `sade-ipa` olabilir. **Add a README file** seçili olsun.
3. **Public** seçersen standart macOS derlemesi ücretsizdir; kaynak kodun herkesçe görülebilir. **Private** seçersen hesabının Actions kotası kullanılır; kotayı ve harcama ayarlarını kontrol et.
4. Depoda **Add file → Upload files** aç. Ayıkladığın `SadeIPA-Cloud` klasörünün **içindeki** dosya ve klasörleri birlikte sürükle. ZIP dosyasını veya dıştaki `SadeIPA-Cloud` klasörünü yükleme; dosyalar depo kökünde olmalı.
5. Yüklemeye `.github` klasörünü de dahil et. **Commit changes** ile varsayılan `main` dalına kaydet. Mevcut README'nin değiştirilmesi normaldir.
6. Depoda `.github/workflows/build-ipa.yml`, `upstream.json`, `upstream.patch`, `overlay/` ve `scripts/` göründüğünü kontrol et.

Yükleme ekranı `.github` klasörünü almıyorsa **Add file → Create new file** ile dosya adını `.github/workflows/build-ipa.yml` yaz; paketteki aynı dosyanın içeriğini yapıştır ve `main` dalına kaydet.

Bu küçük paket, tam SideStore deposunu yüklemeyi gerektirmez. Derleme, sabitlenmiş kaynakları ve alt modülleri indirip arayüz değişikliklerini uygular. Hesap, parola, sertifika ve cihaz eşleştirme dosyası paket içinde bulunmaz; derleme için bunlar istenmez.

## 2. IPA üret

1. Depoda **Actions** sekmesine gir.
2. **Sade IPA derle** akışını seç → **Run workflow** → `main` → **Run workflow**.
3. Çalıştırma tamamlanana kadar bekle. İlk derleme uzun sürebilir.
4. Yeşil tamamlanırsa çalıştırmanın altındaki **Artifacts → SadeIPA** paketini indir.
5. İnen ZIP'i aç. İçinden `SadeIPA.ipa` çıkar; telefona kurulacak dosya budur.

Kırmızı hata varsa çalıştırma sayfasını veya **SadeIPA-derleme-gunlugu** dosyasını incele. Başarısız derlemeyi yeniden başlatmak yerine hatayı düzeltmek gerekir. `Run workflow` görünmüyorsa akışın varsayılan dalda ve doğru yolda bulunduğunu kontrol et.

## 3. Windows'tan iPhone'a kur

1. [Resmî iloader](https://iloader.app/) sitesinden Windows sürümünü indir ve kur. Apple USB sürücüleri için iTunes gereklidir; [SideStore gereksinimleri](https://docs.sidestore.io/docs/installation/prerequisites) bağlantısındaki Windows bölümünü izle.
2. iPhone'u USB ile bağla, kilidini aç ve **Bu bilgisayara güven** isteğini onayla.
3. iloader'ı aç, Apple hesabınla giriş yap ve kendi IPA dosyanı yükleme akışında **SadeIPA.ipa** seç.
4. **Install SideStore (Stable)** düğmesi resmî uygulamayı indirir. Sade IPA için derlediğin dosyayı seçmelisin.
5. iPhone'da **Ayarlar → Genel → VPN ve Aygıt Yönetimi** üzerinden geliştirici hesabına güven. **Ayarlar → Gizlilik ve Güvenlik → Geliştirici Modu** istenirse etkinleştir ve telefonu yeniden başlat.
6. Telefona App Store'dan **LocalDevVPN** kur. Wi-Fi'ye bağlan ve LocalDevVPN'i aç.
7. Sade IPA'da **Ayarlar → Hesap ve kurulum** aç. Aynı Apple hesabıyla giriş yap. Eşleştirme eksikse iloader'ın eşleştirme dosyalarını yönetme özelliğini kullan; kendi IPA yükleme işlemi resmî SideStore düğmesinin tüm otomatik kurulum adımlarını uygulamayabilir.
8. Telefon hâlâ bilgisayara bağlıyken **Tümünü yenile** ile yükleyicinin kendi yenilemesini dene. Başarıyı ve gerçek profil bitiş tarihini kontrol et. Ardından bilgisayar bağlantısını çıkarıp telefondan yenilemeyi tekrar doğrula.

## Kullanım sınırları

Ücretsiz Apple hesabında imza 7 gün sürer; süre bitmeden yenile. iOS arka plan çalışma zamanını belirlediği için tam 7. günde otomatik yenileme garanti değildir. Süre takibi ve son gün hatırlatması bu nedenle bulunur. Ücretsiz hesapta yükleyici dahil 3 aktif uygulama sınırı vardır.

Sonraki işlemler Wi-Fi + LocalDevVPN ile telefondan hedeflenir. iOS güncellemesi, eşleştirme kaydının bozulması veya yükleyicinin imzasının tamamen dolması tekrar bilgisayar kullanımını gerektirebilir. Bu uyarlama, SideStore'un bundle kimliğini korur; mevcut SideStore'u değiştirebilir. Upstream güncellemesi özel arayüzü geri getirebilir.

## Kaynak ve lisans

Altyapı: [SideStore 0.7.0-alpha](https://github.com/SideStore/SideStore/releases/tag/0.7.0-alpha), commit `6032424a0e56c1c319762e786099bdd9186a238b`. Önceki 0.6.4 sürümü Apple tarafındaki değişiklik sonrası giriş yapamadığı için kullanılmıyor. Bu sürüm, upstream'in yayımladığı geçici giriş düzeltmesini içerir ve cihaz testi gerektirir.

Kaynağı yeniden oluşturmak için bu depoyu temiz bir klasöre indir ve `python3 scripts/fetch-upstream.py` çalıştır. `upstream.json` sürüm kimliklerini, `upstream.patch` mevcut dosya değişikliklerini, `overlay/` yeni arayüz kaynaklarını içerir. Özgün telif bildirimleri korunur; uyarlama AGPL-3.0 lisansındadır. `LICENSE` tam metindir. Bu proje resmî SideStore dağıtımı değildir.

Resmî açıklamalar: [GitHub macOS makineleri](https://docs.github.com/en/actions/reference/runners/github-hosted-runners), [GitHub Actions ücret ve kota](https://docs.github.com/en/actions/concepts/billing-and-usage), [akışı elle çalıştırma](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow), [SideStore ilk kurulum](https://docs.sidestore.io/docs/installation/install), [iloader kaynak kodu](https://github.com/nab138/iloader).
