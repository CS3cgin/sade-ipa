import XCTest
@testable import SadeIPACore

final class SadeLifetimeTests: XCTestCase {
    private let issued = Date(timeIntervalSince1970: 1_791_245_000)
    private var expiry: Date { issued.addingTimeInterval(7 * 86_400) }

    private func lifetime(at now: Date) -> SadeLifetime {
        SadeLifetime(renewedAt: issued, expiresAt: expiry, now: now)
    }

    func testNewProfileShowsSevenDays() {
        let value = lifetime(at: issued)
        XCTAssertEqual(value.label, "7 gün")
        XCTAssertEqual(value.fraction, 1)
        XCTAssertFalse(value.needsRenewal)
    }

    func testOneMinuteBeforeExpiryNeverShowsZeroMinutes() {
        XCTAssertEqual(lifetime(at: expiry.addingTimeInterval(-59)).label, "1 dk")
    }

    func testSubDayRemainingUsesHours() {
        XCTAssertEqual(lifetime(at: expiry.addingTimeInterval(-23 * 3_600)).label, "23 saat")
    }

    func testExactExpiryAndPastExpiryAreExpired() {
        for now in [expiry, expiry.addingTimeInterval(100)] {
            let value = lifetime(at: now)
            XCTAssertEqual(value.label, "Süre doldu")
            XCTAssertTrue(value.isExpired)
            XCTAssertEqual(value.fraction, 0)
            XCTAssertNil(value.reminderDate)
        }
    }

    func testRenewalBecomesDueOneDayBeforeExpiry() {
        XCTAssertFalse(lifetime(at: expiry.addingTimeInterval(-86_401)).needsRenewal)
        XCTAssertTrue(lifetime(at: expiry.addingTimeInterval(-86_400)).needsRenewal)
    }

    func testCounterDoesNotResetWhenAppReopens() {
        let later = issued.addingTimeInterval(5 * 86_400)
        XCTAssertEqual(lifetime(at: later).label, "2 gün")
        XCTAssertEqual(lifetime(at: later).expiresAt, expiry)
    }

    func testReminderTargetsSixthDayForSevenDayProfile() {
        XCTAssertEqual(lifetime(at: issued).reminderDate, issued.addingTimeInterval(6 * 86_400))
    }

    func testLateReminderHasFutureTrigger() {
        let now = expiry.addingTimeInterval(-600)
        XCTAssertEqual(lifetime(at: now).reminderDate, now.addingTimeInterval(1))
    }

    func testInvalidDurationDoesNotDivideByZero() {
        let value = SadeLifetime(renewedAt: expiry, expiresAt: expiry, now: issued)
        XCTAssertEqual(value.fraction, 0)
    }

    func testClockMovedBackCannotOverfillProgress() {
        XCTAssertEqual(lifetime(at: issued.addingTimeInterval(-3_600)).fraction, 1)
    }

    func testPaidProfileUsesItsFullDuration() {
        let paidExpiry = issued.addingTimeInterval(365 * 86_400)
        let value = SadeLifetime(renewedAt: issued, expiresAt: paidExpiry,
                                 now: issued.addingTimeInterval(30 * 86_400))
        XCTAssertEqual(value.label, "335 gün")
        XCTAssertEqual(value.fraction, 335.0 / 365.0, accuracy: 0.000001)
        XCTAssertFalse(value.needsRenewal)
        XCTAssertEqual(value.reminderDate, paidExpiry.addingTimeInterval(-86_400))
    }

    func testShortPaidProfileIsNotExtendedToOneYear() {
        let actualExpiry = issued.addingTimeInterval(40 * 86_400)
        let value = SadeLifetime(renewedAt: issued, expiresAt: actualExpiry,
                                 now: issued.addingTimeInterval(39 * 86_400))
        XCTAssertEqual(value.label, "1 gün")
        XCTAssertTrue(value.needsRenewal)
        XCTAssertEqual(value.expiresAt, actualExpiry)
    }

    func testFreeProfileKeepsExpiryUntilSuccessfullyResigned() {
        let afterAccountChange = lifetime(at: issued.addingTimeInterval(2 * 86_400))
        XCTAssertEqual(afterAccountChange.label, "5 gün")
        XCTAssertEqual(afterAccountChange.expiresAt, expiry)

        let resignedAt = issued.addingTimeInterval(2 * 86_400)
        let newExpiry = resignedAt.addingTimeInterval(365 * 86_400)
        let resigned = SadeLifetime(renewedAt: resignedAt, expiresAt: newExpiry, now: resignedAt)
        XCTAssertEqual(resigned.label, "365 gün")
        XCTAssertEqual(resigned.expiresAt, newExpiry)
    }
}
