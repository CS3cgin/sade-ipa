#if canImport(Combine)
import Combine
import Foundation
import XCTest
@testable import SadeIPACore

private final class LockedProgress: @unchecked Sendable {
    private let lock = NSLock()
    private var value = 0

    func publish(_ value: Int, through changes: PassthroughSubject<Void, Never>) {
        lock.lock()
        defer { lock.unlock() }
        self.value = value
        changes.send(Void())
    }

    func read() -> Int {
        lock.lock()
        defer { lock.unlock() }
        return value
    }
}

@MainActor
final class SadeProgressObservationTests: XCTestCase {
    func testPublishingUnderLockDoesNotReenterTheProducer() async {
        let changes = PassthroughSubject<Void, Never>()
        let progress = LockedProgress()
        let producerReturned = expectation(description: "Producer released its lock")
        let delivered = expectation(description: "UI read progress without deadlock")
        let observation = SadeProgressObservation(changes: changes.eraseToAnyPublisher()) {
            XCTAssertTrue(Thread.isMainThread)
            XCTAssertEqual(progress.read(), 1)
            delivered.fulfill()
        }

        DispatchQueue.global().async {
            progress.publish(1, through: changes)
            producerReturned.fulfill()
        }

        await fulfillment(of: [producerReturned, delivered], timeout: 3)
        withExtendedLifetime(observation) {}
    }

    func testTwoConsecutiveOperationsReturnToIdle() async {
        let changes = PassthroughSubject<Void, Never>()
        let progress = LockedProgress()
        var expectedValue = 0
        var delivered: XCTestExpectation?
        let observation = SadeProgressObservation(changes: changes.eraseToAnyPublisher()) {
            XCTAssertTrue(Thread.isMainThread)
            XCTAssertEqual(progress.read(), expectedValue)
            delivered?.fulfill()
        }

        for (index, value) in [1, 0, 1, 0].enumerated() {
            expectedValue = value
            let deliveryExpectation = expectation(description: "Progress transition \(index)")
            delivered = deliveryExpectation
            DispatchQueue.global().async { progress.publish(value, through: changes) }
            await fulfillment(of: [deliveryExpectation], timeout: 3)
        }
        withExtendedLifetime(observation) {}
    }
}
#endif
