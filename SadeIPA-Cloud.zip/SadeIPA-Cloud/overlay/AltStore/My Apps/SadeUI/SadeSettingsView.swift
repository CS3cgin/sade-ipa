#if os(iOS)
import SwiftUI

struct SadeSettingsView: View {
    let onConfigure: () -> Void
    @ObservedObject private var account = SadeAccountStatus.shared
    @State private var backgroundRefresh = UserDefaults.standard.isBackgroundRefreshEnabled
    @State private var reminders = UserDefaults.standard.bool(forKey: SadeReminders.enabledKey)
    @State private var message: String?
    @State private var updatingReminders = false

    var body: some View {
        Form {
            Section {
                SwiftUI.Button(action: onConfigure) {
                    HStack(spacing: 14) {
                        Image(systemName: "person.crop.circle").font(.title2).foregroundStyle(SadeTheme.accent)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Hesap ve kurulum").foregroundStyle(.primary)
                            Text(account.title)
                                .font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Image(systemName: "chevron.right").font(.caption).foregroundStyle(.secondary)
                    }.padding(.vertical, 6)
                }
            } footer: {
                Text("İlk kurulum bilgisayardan yapılır. Sonraki yükleme ve yenilemeler telefonda çalışır.")
            }
            Section {
                Toggle("Arka planda yenilemeyi dene", isOn: $backgroundRefresh)
                    .onChange(of: backgroundRefresh) { UserDefaults.standard.isBackgroundRefreshEnabled = $0 }
                Toggle("1 gün kala hatırlat", isOn: $reminders)
                    .disabled(updatingReminders)
                    .onChange(of: reminders) { enabled in
                        guard enabled != UserDefaults.standard.bool(forKey: SadeReminders.enabledKey) else { return }
                        updatingReminders = true
                        Task { @MainActor in
                            do { try await SadeReminders.shared.setEnabled(enabled) }
                            catch { message = error.localizedDescription }
                            reminders = UserDefaults.standard.bool(forKey: SadeReminders.enabledKey)
                            updatingReminders = false
                        }
                    }
            } header: { Text("Yenileme") } footer: {
                Text("iOS çalışma zamanını belirler. Otomatik yenileme için Wi-Fi ve LocalDevVPN açık olmalı. Süre dolmadan elle de yenileyebilirsin.")
            }
            Section {
                if let teamName = account.teamName {
                    LabeledContentCompat(title: "Seçili hesap", value: teamName)
                }
                LabeledContentCompat(title: "İmza süresi", value: account.signatureDuration)
                LabeledContentCompat(title: "Uygulama sınırı", value: account.appLimit)
                Link("Kurulum rehberi", destination: URL(string: "https://docs.sidestore.io/docs/installation/install")!)
                Link("SideStore · açık kaynak altyapı", destination: URL(string: "https://github.com/SideStore/SideStore")!)
            } header: { Text("Hesap bilgisi") } footer: {
                Text("Kalan süre her uygulamanın gerçek profilinden hesaplanır. Hesap değiştirmek mevcut imzayı uzatmaz; yeni hesapla yenilemelisin.")
            }
        }
        .tint(SadeTheme.accent)
        .modifier(SadeAccountUpdates(account: account))
        .onAppear {
            backgroundRefresh = UserDefaults.standard.isBackgroundRefreshEnabled
            reminders = UserDefaults.standard.bool(forKey: SadeReminders.enabledKey)
        }
        .alert("Hatırlatma", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            SwiftUI.Button("Tamam", role: .cancel) { message = nil }
        } message: { Text(message ?? "") }
    }
}

private struct LabeledContentCompat: View {
    let title: String
    let value: String
    var body: some View {
        HStack {
            Text(title)
            Spacer()
            Text(value).foregroundStyle(.secondary).multilineTextAlignment(.trailing)
        }
    }
}
#endif
