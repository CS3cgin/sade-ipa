#if os(iOS)
import SwiftUI
import CoreData

@MainActor
final class SadeAppsState: ObservableObject {
    @Published var apps: [InstalledApp] = []
    @Published var isReady = false
    @Published var operationProgress: Progress?
    var isBusy: Bool { operationProgress != nil }
}

enum SadeTheme {
    static let accent = Color(red: 0.25, green: 0.32, blue: 0.95)
    static let background = Color(uiColor: .systemGroupedBackground)
    static let card = Color(uiColor: .secondarySystemGroupedBackground)
}

struct SadeAppsView: View {
    @ObservedObject var state: SadeAppsState
    @ObservedObject private var manager = AppManager.shared
    let onImport: () -> Void
    let onRefreshAll: () -> Void
    let onRefresh: (InstalledApp) -> Void
    let onOpen: (InstalledApp) -> Void
    let onSettings: () -> Void

    private var busy: Bool { state.isBusy || manager.isActivelyManagingAnyApp }
    private var activeApps: [InstalledApp] { state.apps.filter(\.isActive) }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                intro
                importButton
                if let progress = state.operationProgress {
                    TimelineView(.periodic(from: Date(), by: 1)) { _ in
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Text("İşlem sürüyor").font(.subheadline.weight(.medium))
                                Spacer()
                                Text("%\(Int(progress.fractionCompleted * 100))").monospacedDigit()
                            }
                            ProgressView(value: progress.fractionCompleted)
                                .tint(SadeTheme.accent)
                        }
                        .padding(18)
                        .background(SadeTheme.card, in: RoundedRectangle(cornerRadius: 20))
                        .accessibilityElement(children: .combine)
                    }
                }
                appsSection
                connectionHint
                Text("Ücretsiz hesapta toplam 3 uygulama. Bu uygulama da bir yer kullanır.")
                    .font(.caption).foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .multilineTextAlignment(.center)
            }
            .padding(24)
            .frame(maxWidth: 600)
            .frame(maxWidth: .infinity)
        }
        .background(SadeTheme.background)
        .tint(SadeTheme.accent)
    }

    private var intro: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Uygulamaların").font(.largeTitle.bold()).lineLimit(1).minimumScaleFactor(0.75)
                Spacer()
                HStack(spacing: 6) {
                    Circle().fill(state.isReady ? Color.green : Color.orange).frame(width: 6, height: 6)
                    Text(state.isReady ? "Hazır" : "Bağlantı yok").font(.caption.weight(.medium))
                }
                .padding(.horizontal, 10).padding(.vertical, 7)
                .background(SadeTheme.card, in: Capsule())
            }
            Text("IPA yükle. Süreni takip et.")
                .font(.subheadline).foregroundStyle(.secondary)
        }
    }

    private var importButton: some View {
        SwiftUI.Button(action: onImport) {
            HStack(spacing: 16) {
                Image(systemName: "plus").font(.title2.weight(.semibold))
                    .frame(width: 48, height: 48)
                    .background(.white.opacity(0.15), in: RoundedRectangle(cornerRadius: 14))
                VStack(alignment: .leading, spacing: 4) {
                    Text("IPA yükle").font(.headline)
                    Text("Dosyalar’dan bir uygulama seç").font(.subheadline).opacity(0.85)
                }
                Spacer(minLength: 0)
                Image(systemName: "arrow.up.doc").font(.title3)
            }
            .foregroundStyle(.white).padding(20)
            .background(SadeTheme.accent, in: RoundedRectangle(cornerRadius: 24))
        }
        .buttonStyle(.plain).disabled(busy)
        .opacity(busy ? 0.6 : 1)
        .accessibilityIdentifier("sade.import")
    }

    private var appsSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("Yüklü uygulamalar").font(.headline)
                Text("\(activeApps.count)").font(.caption.weight(.semibold))
                    .padding(.horizontal, 7).padding(.vertical, 3)
                    .background(SadeTheme.card, in: Capsule())
                Spacer()
                SwiftUI.Button("Tümünü yenile", action: onRefreshAll)
                    .font(.subheadline.weight(.semibold))
                    .frame(minHeight: 44)
                    .disabled(busy || activeApps.isEmpty)
                    .accessibilityIdentifier("sade.refreshAll")
            }
            if state.apps.isEmpty {
                VStack(spacing: 12) {
                    Image(systemName: "square.stack.3d.up").font(.system(size: 34, weight: .light))
                        .foregroundStyle(SadeTheme.accent)
                    Text("İlk uygulamanı ekle").font(.headline)
                    Text("IPA dosyanı seçtiğinde yükleme burada başlayacak.")
                        .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity).padding(.vertical, 36).padding(.horizontal, 20)
                .background(SadeTheme.card, in: RoundedRectangle(cornerRadius: 22))
            } else {
                TimelineView(.periodic(from: Date(), by: 60)) { context in
                    LazyVStack(spacing: 12) {
                        ForEach(state.apps, id: \.objectID) { app in
                            SadeAppRow(app: app, now: context.date, busy: busy,
                                       onRefresh: { onRefresh(app) }, onOpen: { onOpen(app) })
                        }
                    }
                }
            }
        }
    }

    private var connectionHint: some View {
        SwiftUI.Button(action: onSettings) {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: state.isReady ? "arrow.triangle.2.circlepath" : "wifi.exclamationmark")
                    .foregroundStyle(SadeTheme.accent).font(.title3)
                VStack(alignment: .leading, spacing: 4) {
                    Text(state.isReady ? "Süre dolmadan yenile" : "Bağlantını kontrol et")
                        .font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                    Text(state.isReady
                         ? "Arka plan yenileme açıkken iOS fırsat buldukça yenilemeyi dener."
                         : "Yüklemek ve yenilemek için Wi-Fi ve LocalDevVPN açık olmalı.")
                        .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.right").font(.caption).foregroundStyle(.secondary)
            }
            .padding(18).background(SadeTheme.card, in: RoundedRectangle(cornerRadius: 20))
        }.buttonStyle(.plain)
    }
}

private struct SadeAppRow: View {
    @ObservedObject var app: InstalledApp
    let now: Date
    let busy: Bool
    let onRefresh: () -> Void
    let onOpen: () -> Void
    @State private var icon: UIImage?

    private var lifetime: SadeLifetime {
        SadeLifetime(renewedAt: app.refreshedDate, expiresAt: app.expirationDate, now: now)
    }
    private var statusColor: Color { lifetime.needsRenewal ? .orange : SadeTheme.accent }

    var body: some View {
        VStack(spacing: 14) {
            HStack(spacing: 14) {
                Group {
                    if let icon { Image(uiImage: icon).resizable().scaledToFit() }
                    else {
                        Text(String(app.name.prefix(1)).uppercased())
                            .font(.title2.bold()).foregroundStyle(SadeTheme.accent)
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .background(SadeTheme.accent.opacity(0.08))
                    }
                }
                .frame(width: 52, height: 52).clipShape(RoundedRectangle(cornerRadius: 14))
                .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 5) {
                    Text(app.name).font(.headline).lineLimit(1)
                    Text(app.isActive ? "Sürüm \(app.version)" : "Devre dışı")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Spacer(minLength: 4)
                VStack(alignment: .trailing, spacing: 4) {
                    Text(app.isActive ? lifetime.label : "Pasif")
                        .font(.subheadline.bold()).monospacedDigit().foregroundStyle(statusColor)
                    Text(app.isActive ? "kalan süre" : "yenileme kapalı")
                        .font(.caption2).foregroundStyle(.secondary)
                }
            }
            if app.isActive {
                ProgressView(value: lifetime.fraction).tint(statusColor)
                HStack {
                    Text("Bitiş: \(app.expirationDate.formatted(.dateTime.day().month(.abbreviated).hour().minute().locale(Locale(identifier: "tr_TR"))))")
                        .font(.caption2).foregroundStyle(.secondary)
                    Spacer()
                    SwiftUI.Button(action: onRefresh) {
                        Label(app.isRefreshing ? "Yenileniyor" : "Yenile", systemImage: "arrow.clockwise")
                            .font(.caption.weight(.semibold))
                    }
                    .frame(minHeight: 44)
                    .disabled(busy || app.isRefreshing)
                }
            }
        }
        .padding(18).background(SadeTheme.card, in: RoundedRectangle(cornerRadius: 22))
        .contextMenu {
            if app.isActive {
                SwiftUI.Button(action: onOpen) { Label("Uygulamayı aç", systemImage: "arrow.up.forward.app") }
                SwiftUI.Button(action: onRefresh) { Label("İmzayı yenile", systemImage: "arrow.clockwise") }.disabled(busy)
            }
        }
        .task(id: app.hasAlternateIcon) { icon = try? await app.loadIcon() }
    }
}
#endif
