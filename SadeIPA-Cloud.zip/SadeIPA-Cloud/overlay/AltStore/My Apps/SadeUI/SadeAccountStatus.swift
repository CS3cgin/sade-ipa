#if os(iOS)
import SwiftUI
import CoreData
import SideSign

/// Display the team actually selected by the signing engine. An account change
/// does not change any installed app's provisioning profile or expiry date.
@MainActor
final class SadeAccountStatus: ObservableObject {
    static let shared = SadeAccountStatus()

    enum Kind: Equatable {
        case signedOut, free, paid, unknown
    }

    @Published private(set) var kind = Kind.signedOut
    @Published private(set) var teamName: String?

    private init() {}

    func refresh() {
        let team = DatabaseManager.shared.activeTeam()
        let nextKind: Kind
        if let team {
            switch team.type {
            case .free: nextKind = .free
            case .individual, .organization: nextKind = .paid
            case .unknown: nextKind = .unknown
            @unknown default: nextKind = .unknown
            }
        } else {
            nextKind = .signedOut
        }
        if kind != nextKind { kind = nextKind }
        if teamName != team?.name { teamName = team?.name }
    }

    var title: String {
        switch kind {
        case .signedOut: return "Giriş yapılmadı"
        case .free: return "Ücretsiz Apple hesabı"
        case .paid: return "Apple Developer hesabı"
        case .unknown: return "Hesap türü doğrulanamadı"
        }
    }

    var signatureDuration: String {
        switch kind {
        case .signedOut: return "Giriş yapınca belirlenir"
        case .free: return "7 gün"
        case .paid: return "365 güne kadar"
        case .unknown: return "Profile göre"
        }
    }

    var appLimit: String {
        switch kind {
        case .signedOut, .unknown: return "Hesap doğrulanınca belirlenir"
        case .free: return "Toplam 3 aktif uygulama"
        case .paid: return "3 uygulama sınırı yok"
        }
    }

    var appListNote: String {
        switch kind {
        case .signedOut: return "Ücretsiz veya ücretli Apple hesabınla giriş yap."
        case .free: return "Ücretsiz hesap · Sade IPA dahil 3 aktif uygulama."
        case .paid: return "Apple Developer hesabı · 3 uygulama sınırı yok."
        case .unknown: return "Hesap türü doğrulanamadı. Kalan süre kurulu profilden gösterilir."
        }
    }
}

/// Both tabs update after sign-in, sign-out, team changes and returning from
/// Settings. Core Data merges background sign-in results into its main context.
struct SadeAccountUpdates: ViewModifier {
    @ObservedObject var account: SadeAccountStatus

    func body(content: Content) -> some View {
        content
            .onAppear { account.refresh() }
            .onReceive(NotificationCenter.default.publisher(
                for: .NSManagedObjectContextObjectsDidChange,
                object: DatabaseManager.shared.viewContext)) { _ in account.refresh() }
            .onReceive(NotificationCenter.default.publisher(
                for: UIApplication.didBecomeActiveNotification)) { _ in account.refresh() }
    }
}
#endif
