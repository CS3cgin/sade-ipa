import Foundation

/// Elapsed seconds rather than calendar days keep the counter correct at
/// midnight and across timezone changes. The engine supplies the profile dates.
public struct SadeLifetime {
    public let renewedAt: Date
    public let expiresAt: Date
    public let now: Date

    public init(renewedAt: Date, expiresAt: Date, now: Date) {
        self.renewedAt = renewedAt
        self.expiresAt = expiresAt
        self.now = now
    }

    public var remaining: TimeInterval { max(0, expiresAt.timeIntervalSince(now)) }
    public var isExpired: Bool { expiresAt <= now }
    public var needsRenewal: Bool { remaining <= 86_400 }

    public var label: String {
        if isExpired { return "Süre doldu" }
        if remaining < 3_600 { return "\(max(1, Int(ceil(remaining / 60)))) dk" }
        if remaining < 86_400 { return "\(Int(ceil(remaining / 3_600))) saat" }
        return "\(Int(ceil(remaining / 86_400))) gün"
    }

    public var fraction: Double {
        let duration = expiresAt.timeIntervalSince(renewedAt)
        guard duration > 0 else { return 0 }
        return min(1, max(0, remaining / duration))
    }

    public var reminderDate: Date? {
        guard !isExpired else { return nil }
        return max(now.addingTimeInterval(1), expiresAt.addingTimeInterval(-86_400))
    }
}
