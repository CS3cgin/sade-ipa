#if canImport(Combine)
import Combine
import Foundation

/// AppManager publishes progress while holding its own lock on a worker thread.
/// Queue the UI callback so publishing never calls SwiftUI back under that lock.
@MainActor
final class SadeProgressObservation {
    private let subscription: AnyCancellable

    init(changes: AnyPublisher<Void, Never>, didChange: @escaping @MainActor () -> Void) {
        subscription = changes.sink { _ in
            Task { @MainActor in didChange() }
        }
    }
}
#endif
