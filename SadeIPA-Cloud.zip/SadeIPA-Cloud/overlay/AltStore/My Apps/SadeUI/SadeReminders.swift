#if os(iOS)
import Foundation
import UserNotifications

@MainActor
final class SadeReminders {
    static let shared = SadeReminders()
    static let enabledKey = "sadeRemindersEnabled"
    private let center = UNUserNotificationCenter.current()
    private let prefix = "sadeipa.expiry."
    private let scheduledKey = "sadeReminderScheduledExpirations"
    private var synchronizationTask: Task<Void, Never>?

    enum ReminderError: LocalizedError {
        case permissionDenied
        var errorDescription: String? {
            "Bildirim izni kapalı. iPhone Ayarlar uygulamasından bu uygulamanın bildirimlerini açabilirsin."
        }
    }

    func setEnabled(_ enabled: Bool) async throws {
        if enabled {
            guard try await center.requestAuthorization(options: [.alert, .sound]) else {
                throw ReminderError.permissionDenied
            }
        }
        UserDefaults.standard.set(enabled, forKey: Self.enabledKey)
        synchronize()
    }

    func synchronize() {
        let previousTask = synchronizationTask
        previousTask?.cancel()
        // Snapshot on the view context's main actor. No managed objects cross an await.
        let now = Date()
        let entries = InstalledApp.all(in: DatabaseManager.shared.viewContext)
            .filter { $0.isActive && $0.expirationDate > now }
            .sorted { $0.expirationDate < $1.expirationDate }
            .prefix(60)
            .map { ($0.bundleIdentifier, $0.name, $0.refreshedDate, $0.expirationDate) }
        let enabled = UserDefaults.standard.bool(forKey: Self.enabledKey)
        synchronizationTask = Task { @MainActor in
            await previousTask?.value
            guard !Task.isCancelled else { return }
            let pending = await center.pendingNotificationRequests()
            guard !Task.isCancelled else { return }
            let currentIDs = Set(entries.map { prefix + $0.0 })
            let obsolete = pending.filter { $0.identifier.hasPrefix(prefix) && (!enabled || !currentIDs.contains($0.identifier)) }
            center.removePendingNotificationRequests(withIdentifiers: obsolete.map(\.identifier))
            guard enabled else {
                UserDefaults.standard.removeObject(forKey: scheduledKey)
                return
            }
            var scheduled = UserDefaults.standard.dictionary(forKey: scheduledKey) as? [String: Double] ?? [:]
            scheduled = scheduled.filter { currentIDs.contains(prefix + $0.key) }
            for (identifier, name, renewedAt, expiresAt) in entries {
                guard !Task.isCancelled else { return }
                // Do not repeatedly notify after entering the final 24 hours.
                guard scheduled[identifier] != expiresAt.timeIntervalSince1970 else { continue }
                let lifetime = SadeLifetime(renewedAt: renewedAt, expiresAt: expiresAt, now: now)
                guard let reminderDate = lifetime.reminderDate else { continue }
                let content = UNMutableNotificationContent()
                content.title = "Yenileme zamanı"
                content.body = "\(name) uygulamasının süresi 1 gün içinde dolacak."
                content.sound = .default
                let trigger = UNTimeIntervalNotificationTrigger(timeInterval: max(1, reminderDate.timeIntervalSinceNow), repeats: false)
                do {
                    try await center.add(UNNotificationRequest(identifier: prefix + identifier, content: content, trigger: trigger))
                    scheduled[identifier] = expiresAt.timeIntervalSince1970
                    UserDefaults.standard.set(scheduled, forKey: scheduledKey)
                } catch {
                    // Keep failures visible in the existing diagnostics without touching credentials.
                    debugLog("[SadeReminders] Could not schedule reminder: \(error.localizedDescription)")
                }
            }
            UserDefaults.standard.set(scheduled, forKey: scheduledKey)
        }
    }
}
#endif
